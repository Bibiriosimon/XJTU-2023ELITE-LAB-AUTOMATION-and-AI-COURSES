%% 实验3.3 超前/滞后校正对比（MATLAB 实现，无需 Simulink）
% 被控对象开环传递函数: G(s) = 20 / (0.6 s^2 + s)
% 给定超前校正环节: Gc_lead(s) = (0.8 s + 1) / (0.08 s + 1)
% 给定滞后校正环节: Gc_lag(s)  = (5 s + 1) / (30 s + 1)
% 任务:
% 1) 在同一脚本中比较原系统、超前校正、滞后校正的阶跃响应。
% 2) 记录超调量 Mp 和调节时间 Ts(2%准则)，并判断是否满足 Mp < 20%。
% 3) 允许适度调整校正参数，观察参数变化与性能优化的关系（留有接口）。

clear; clc; close all;

%% 1. 定义被控对象和默认校正参数
% 植物: G(s) = 20 / (0.6 s^2 + s)
numG = 20;
denG = [0.6 1 0];
G = tf(numG, denG);

% 可调校正参数（可根据需要修改以优化 Mp 或 Ts）
lead_zero = 0.8;   % 超前零点系数 (0.8 s + 1)
lead_pole = 0.05;  % 超前极点系数 (0.08 s + 1)
lead_gain = 1;     % 超前环节增益，可微调

lag_zero = 8;      % 滞后零点系数 (5 s + 1)
lag_pole = 120;     % 滞后极点系数 (30 s + 1)
lag_gain = 0.7;      % 滞后环节增益，可微调

% 构造校正环节
Gc_lead = lead_gain * tf([lead_zero 1], [lead_pole 1]);
Gc_lag  = lag_gain  * tf([lag_zero 1],  [lag_pole 1]);

% 开环组合（方便后续分析）
L0      = G;
L_lead  = Gc_lead * G;
L_lag   = Gc_lag  * G;

%% 2. 闭环传递函数与阶跃响应
T0     = feedback(L0, 1);
T_lead = feedback(L_lead, 1);
T_lag  = feedback(L_lag, 1);

t_plot = 0:0.01:15;  % 默认展示前 15 s，便于观察初始动态
[y0, t0]     = step(T0, t_plot);
[y_lead, tl] = step(T_lead, t_plot);
[y_lag, tg]  = step(T_lag, t_plot);

%% 3. 计算时域指标 (Mp, Ts)
info0     = stepinfo(T0);
info_lead = stepinfo(T_lead);
info_lag  = stepinfo(T_lag);

fprintf('================= 阶跃响应指标 =================\n');
fprintf('原系统:       Mp = %6.2f%%, Ts = %6.2f s\n', info0.Overshoot, info0.SettlingTime);
fprintf('超前校正后:   Mp = %6.2f%%, Ts = %6.2f s\n', info_lead.Overshoot, info_lead.SettlingTime);
fprintf('滞后校正后:   Mp = %6.2f%%, Ts = %6.2f s\n', info_lag.Overshoot,  info_lag.SettlingTime);

% 简单判定是否满足 Mp < 20%
targetMp = 20;
pass_lead = info_lead.Overshoot < targetMp;
pass_lag  = info_lag.Overshoot  < targetMp;

fprintf('\n判定 (超调量 < %d%%):\n', targetMp);
fprintf('超前校正: %s\n', ternary(pass_lead, '满足', '不满足'));
fprintf('滞后校正: %s\n', ternary(pass_lag,  '满足', '不满足'));

%% 4. 绘制阶跃响应对比
figure('Name', '阶跃响应对比', 'Position', [100, 100, 900, 500]);
plot(t0, y0, 'b-', 'LineWidth', 2, 'DisplayName', '原系统'); hold on;
plot(tl, y_lead, 'r--', 'LineWidth', 2, 'DisplayName', '超前校正');
plot(tg, y_lag, 'g-.', 'LineWidth', 2, 'DisplayName', '滞后校正');
yline(1, 'k:', 'LineWidth', 1, 'DisplayName', '稳态值');
grid on; xlabel('时间 (s)'); ylabel('响应'); xlim([0 15]);
title('原系统 vs 超前 vs 滞后 校正阶跃响应');
legend('Location', 'southeast');

%% 5. 可选: 频域对比（若需查看相位/幅值变化可打开）
%{
% w = logspace(-2, 2, 2000);
% figure('Name', 'Bode 对比', 'Position', [100, 100, 900, 700]);
% bode(L0, 'b', L_lead, 'r', L_lag, 'g', {min(w), max(w)});
% legend('原系统 L0', '超前校正 L_{lead}', '滞后校正 L_{lag}', 'Location', 'southwest');
% grid on;
%}

%% 6. 可选: 参数调节建议
% - 需要减小超调: 降低闭环高频增益，例如减小 lead_gain，或减小超前零点/增大超前极点（缩小相位超前角）。
% - 需要加快响应/缩短 Ts: 提升 lead_gain 或适当减小 lead_pole，保持 lead_zero/lead_pole 的比值在 5~10 左右以获得合适相位超前。
% - 滞后校正主要改善稳态精度但会降低带宽，如需要保持 Mp < 20%，可适当降低 lag_gain 或增大 lag_pole 以减小低频放大。

%% 7. 参数变化对性能的影响 (示例: 调整超前/滞后增益)
lead_gains = [0.6 1 1.4];
lag_gains  = [0.6 1 1.2];

lead_mp = zeros(size(lead_gains));
lead_ts = zeros(size(lead_gains));
lag_mp  = zeros(size(lag_gains));
lag_ts  = zeros(size(lag_gains));

for i = 1:numel(lead_gains)
	Gi = lead_gains(i) * tf([lead_zero 1], [lead_pole 1]);
	Ti = feedback(Gi * G, 1);
	info_i = stepinfo(Ti);
	lead_mp(i) = info_i.Overshoot;
	lead_ts(i) = info_i.SettlingTime;
end

for i = 1:numel(lag_gains)
	Gi = lag_gains(i) * tf([lag_zero 1], [lag_pole 1]);
	Ti = feedback(Gi * G, 1);
	info_i = stepinfo(Ti);
	lag_mp(i) = info_i.Overshoot;
	lag_ts(i) = info_i.SettlingTime;
end

fprintf('\n===== 参数敏感性: 增益扫描 (Mp, Ts) =====\n');
fprintf('超前增益 | Mp(%%) | Ts(s)\n');
for i = 1:numel(lead_gains)
	fprintf('%8.2f | %5.2f | %6.2f\n', lead_gains(i), lead_mp(i), lead_ts(i));
end
fprintf('滞后增益 | Mp(%%) | Ts(s)\n');
for i = 1:numel(lag_gains)
	fprintf('%8.2f | %5.2f | %6.2f\n', lag_gains(i), lag_mp(i), lag_ts(i));
end

figure('Name', '参数敏感性曲线', 'Position', [150, 150, 950, 400]);
subplot(1,2,1);
plot(lead_gains, lead_mp, 'r-o', 'LineWidth', 1.8, 'DisplayName', '超前 Mp'); hold on;
plot(lag_gains, lag_mp, 'g-s', 'LineWidth', 1.8, 'DisplayName', '滞后 Mp');
yline(20, 'k--', 'LineWidth', 1, 'DisplayName', 'Mp=20%');
grid on; xlabel('增益'); ylabel('超调量 Mp (%)'); title('增益 vs 超调'); legend('Location', 'best');

subplot(1,2,2);
plot(lead_gains, lead_ts, 'r-o', 'LineWidth', 1.8, 'DisplayName', '超前 Ts'); hold on;
plot(lag_gains, lag_ts, 'g-s', 'LineWidth', 1.8, 'DisplayName', '滞后 Ts');
grid on; xlabel('增益'); ylabel('调节时间 Ts (s)'); title('增益 vs 调节时间'); legend('Location', 'best');

%% 8. 零极点系数敏感性 (超前/滞后)
lead_zeros = [0.5 0.8 1.1];
lead_poles = [0.04 0.08 0.12];
lag_zeros  = [3 5 8];
lag_poles  = [60 120 200];

lead_zero_mp = zeros(size(lead_zeros));
lead_zero_ts = zeros(size(lead_zeros));
lead_pole_mp = zeros(size(lead_poles));
lead_pole_ts = zeros(size(lead_poles));
lag_zero_mp  = zeros(size(lag_zeros));
lag_zero_ts  = zeros(size(lag_zeros));
lag_pole_mp  = zeros(size(lag_poles));
lag_pole_ts  = zeros(size(lag_poles));

for i = 1:numel(lead_zeros)
	Gi = lead_gain * tf([lead_zeros(i) 1], [lead_pole 1]);
	Ti = feedback(Gi * G, 1);
	info_i = stepinfo(Ti);
	lead_zero_mp(i) = info_i.Overshoot;
	lead_zero_ts(i) = info_i.SettlingTime;
end

for i = 1:numel(lead_poles)
	Gi = lead_gain * tf([lead_zero 1], [lead_poles(i) 1]);
	Ti = feedback(Gi * G, 1);
	info_i = stepinfo(Ti);
	lead_pole_mp(i) = info_i.Overshoot;
	lead_pole_ts(i) = info_i.SettlingTime;
end

for i = 1:numel(lag_zeros)
	Gi = lag_gain * tf([lag_zeros(i) 1], [lag_pole 1]);
	Ti = feedback(Gi * G, 1);
	info_i = stepinfo(Ti);
	lag_zero_mp(i) = info_i.Overshoot;
	lag_zero_ts(i) = info_i.SettlingTime;
end

for i = 1:numel(lag_poles)
	Gi = lag_gain * tf([lag_zero 1], [lag_poles(i) 1]);
	Ti = feedback(Gi * G, 1);
	info_i = stepinfo(Ti);
	lag_pole_mp(i) = info_i.Overshoot;
	lag_pole_ts(i) = info_i.SettlingTime;
end

fprintf('\n===== 参数敏感性: 零极点扫描 (Mp, Ts) =====\n');
fprintf('超前零点 | Mp(%%) | Ts(s)\n');
for i = 1:numel(lead_zeros)
	fprintf('%8.2f | %5.2f | %6.2f\n', lead_zeros(i), lead_zero_mp(i), lead_zero_ts(i));
end
fprintf('超前极点 | Mp(%%) | Ts(s)\n');
for i = 1:numel(lead_poles)
	fprintf('%8.2f | %5.2f | %6.2f\n', lead_poles(i), lead_pole_mp(i), lead_pole_ts(i));
end
fprintf('滞后零点 | Mp(%%) | Ts(s)\n');
for i = 1:numel(lag_zeros)
	fprintf('%8.2f | %5.2f | %6.2f\n', lag_zeros(i), lag_zero_mp(i), lag_zero_ts(i));
end
fprintf('滞后极点 | Mp(%%) | Ts(s)\n');
for i = 1:numel(lag_poles)
	fprintf('%8.2f | %5.2f | %6.2f\n', lag_poles(i), lag_pole_mp(i), lag_pole_ts(i));
end

figure('Name', '零极点敏感性', 'Position', [180, 180, 1050, 650]);
subplot(2,2,1);
yyaxis left;  plot(lead_zeros, lead_zero_mp, 'r-o', 'LineWidth', 1.6, 'DisplayName', 'Mp'); ylabel('Mp (%)');
yyaxis right; plot(lead_zeros, lead_zero_ts, 'b--s', 'LineWidth', 1.6, 'DisplayName', 'Ts'); ylabel('Ts (s)');
grid on; xlabel('超前零点系数'); title('超前零点 vs Mp/Ts');

subplot(2,2,2);
yyaxis left;  plot(lead_poles, lead_pole_mp, 'r-o', 'LineWidth', 1.6, 'DisplayName', 'Mp'); ylabel('Mp (%)');
yyaxis right; plot(lead_poles, lead_pole_ts, 'b--s', 'LineWidth', 1.6, 'DisplayName', 'Ts'); ylabel('Ts (s)');
grid on; xlabel('超前极点系数'); title('超前极点 vs Mp/Ts');

subplot(2,2,3);
yyaxis left;  plot(lag_zeros, lag_zero_mp, 'g-o', 'LineWidth', 1.6, 'DisplayName', 'Mp'); ylabel('Mp (%)');
yyaxis right; plot(lag_zeros, lag_zero_ts, 'k--s', 'LineWidth', 1.6, 'DisplayName', 'Ts'); ylabel('Ts (s)');
grid on; xlabel('滞后零点系数'); title('滞后零点 vs Mp/Ts');

subplot(2,2,4);
yyaxis left;  plot(lag_poles, lag_pole_mp, 'g-o', 'LineWidth', 1.6, 'DisplayName', 'Mp'); ylabel('Mp (%)');
yyaxis right; plot(lag_poles, lag_pole_ts, 'k--s', 'LineWidth', 1.6, 'DisplayName', 'Ts'); ylabel('Ts (s)');
grid on; xlabel('滞后极点系数'); title('滞后极点 vs Mp/Ts');

%% 小工具: 三目判断打印
function out = ternary(cond, a, b)
% cond 为 true 则返回 a，否则返回 b
if cond
	out = a;
else
	out = b;
end
end
