%% 实验3.1 超前校正传递函数设计
% 已知单位负反馈系统被控对象的开环传递函数为 G(s) = K / [(s+1)(0.5s+1)(0.002s+1)]
% 设计超前校正传递函数
% 要求: K >= 100, 相位裕度 50°

clear; clc; close all;

%% 1. 定义原系统参数
K = 100;  % 开环增益

% 原系统传递函数 G(s) = K / [(s+1)(0.5s+1)(0.002s+1)]
num0 = K;
den0 = conv(conv([1 1], [0.5 1]), [0.002 1]);  % 展开分母多项式

G0 = tf(num0, den0);  % 原开环传递函数

disp('========== 原系统开环传递函数 ==========');
G0

%% 2. 分析原系统的频率特性
[Gm0, Pm0, Wcg0, Wcp0] = margin(G0);

disp('========== 原系统性能指标 ==========');
fprintf('原系统幅值裕度 Gm = %.4f dB\n', 20*log10(Gm0));
fprintf('原系统相位裕度 Pm = %.4f°\n', Pm0);
fprintf('原系统幅值穿越频率 Wcg = %.4f rad/s\n', Wcg0);
fprintf('原系统相位穿越频率 Wcp = %.4f rad/s\n', Wcp0);

%% 3. 设计超前校正环节
% 超前校正传递函数形式: Gc(s) = (aTs + 1) / (Ts + 1), 其中 a > 1

% 设计步骤:
% (1) 确定所需的相位裕度
Pm_desired = 50;  % 期望相位裕度 (度)

% (2) 计算需要补偿的相位角 (加上安全裕量 5-12°)
epsilon = 10;  % 安全裕量
phi_m = Pm_desired - Pm0 + epsilon;  % 超前校正提供的最大相位角

disp('========== 超前校正设计 ==========');
fprintf('需要补偿的相位角 φm = %.4f°\n', phi_m);

% (3) 计算超前校正参数 a
% sin(φm) = (a-1)/(a+1), 解得 a = (1+sin(φm))/(1-sin(φm))
phi_m_rad = phi_m * pi / 180;
a = (1 + sin(phi_m_rad)) / (1 - sin(phi_m_rad));

fprintf('超前校正参数 a = %.4f\n', a);

% (4) 确定新的穿越频率 wc_new
% 在新的穿越频率处，原系统的幅值应为 -10*log10(a) dB
% 使原系统在 wc_new 处的增益为 1/sqrt(a)
target_gain = -10*log10(a);
fprintf('目标增益补偿 = %.4f dB\n', target_gain);

% 通过数值方法找到新的穿越频率
w = logspace(-2, 4, 10000);
[mag0, phase0] = bode(G0, w);
mag0 = squeeze(mag0);
phase0 = squeeze(phase0);
mag0_dB = 20*log10(mag0);

% 找到幅值为 -10*log10(a) 的频率点
[~, idx] = min(abs(mag0_dB - target_gain));
wc_new = w(idx);

fprintf('新的穿越频率 wc_new = %.4f rad/s\n', wc_new);

% (5) 计算时间常数 T
% 最大相位超前发生在 wm = 1/(T*sqrt(a))
% 令 wm = wc_new, 则 T = 1/(wc_new * sqrt(a))
T = 1 / (wc_new * sqrt(a));

fprintf('超前校正时间常数 T = %.6f s\n', T);
fprintf('超前校正零点时间常数 aT = %.6f s\n', a*T);

%% 4. 构建超前校正传递函数
% Gc(s) = (aTs + 1) / (Ts + 1)
num_c = [a*T 1];
den_c = [T 1];

Gc = tf(num_c, den_c);

disp('========== 超前校正传递函数 ==========');
fprintf('Gc(s) = (%.6f*s + 1) / (%.6f*s + 1)\n', a*T, T);
Gc

%% 5. 计算校正后的开环传递函数
G_corrected = Gc * G0;

disp('========== 校正后开环传递函数 ==========');
G_corrected

%% 6. 验证校正后系统的性能
[Gm_c, Pm_c, Wcg_c, Wcp_c] = margin(G_corrected);

disp('========== 校正后系统性能指标 ==========');
fprintf('校正后幅值裕度 Gm = %.4f dB\n', 20*log10(Gm_c));
fprintf('校正后相位裕度 Pm = %.4f°\n', Pm_c);
fprintf('校正后幅值穿越频率 Wcg = %.4f rad/s\n', Wcg_c);
fprintf('校正后相位穿越频率 Wcp = %.4f rad/s\n', Wcp_c);

%% 7. 验证是否满足要求
disp('========== 验证结果 ==========');
if Pm_c >= Pm_desired
    fprintf('√ 相位裕度满足要求: %.4f° >= %.4f°\n', Pm_c, Pm_desired);
else
    fprintf('× 相位裕度不满足要求: %.4f° < %.4f°\n', Pm_c, Pm_desired);
end

if K >= 100
    fprintf('√ 开环增益满足要求: K = %d >= 100\n', K);
else
    fprintf('× 开环增益不满足要求: K = %d < 100\n', K);
end

%% 8. 绘制伯德图 (校正前后对比，显示在同一张图上)
figure('Name', '校正前后伯德图对比', 'Position', [100, 100, 1000, 700]);

% 获取伯德图数据
[mag0_plot, phase0_plot, w_plot] = bode(G0, w);
mag0_plot = squeeze(mag0_plot);
phase0_plot = squeeze(phase0_plot);

[mag_c_plot, phase_c_plot] = bode(G_corrected, w);
mag_c_plot = squeeze(mag_c_plot);
phase_c_plot = squeeze(phase_c_plot);

[mag_gc, phase_gc] = bode(Gc, w);
mag_gc = squeeze(mag_gc);
phase_gc = squeeze(phase_gc);

% 幅频特性曲线
subplot(2,1,1);
semilogx(w_plot, 20*log10(mag0_plot), 'b-', 'LineWidth', 2, 'DisplayName', '校正前 G_0(s)');
hold on;
semilogx(w_plot, 20*log10(mag_c_plot), 'r-', 'LineWidth', 2, 'DisplayName', '校正后 G_c(s)G_0(s)');
semilogx(w_plot, 20*log10(mag_gc), 'g--', 'LineWidth', 1.5, 'DisplayName', '超前校正 G_c(s)');

% 标注穿越频率
xline(Wcp0, 'b:', 'LineWidth', 1);
xline(Wcp_c, 'r:', 'LineWidth', 1);
yline(0, 'k--', 'LineWidth', 1);

% 标注穿越频率点
plot(Wcp0, 0, 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b', 'HandleVisibility', 'off');
plot(Wcp_c, 0, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'HandleVisibility', 'off');

grid on;
xlabel('频率 \omega (rad/s)', 'FontSize', 11);
ylabel('幅值 (dB)', 'FontSize', 11);
title('幅频特性曲线对比', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'southwest', 'FontSize', 10);
xlim([1e-1, 1e4]);
set(gca, 'FontSize', 10);

% 相频特性曲线
subplot(2,1,2);
semilogx(w_plot, phase0_plot, 'b-', 'LineWidth', 2, 'DisplayName', '校正前 G_0(s)');
hold on;
semilogx(w_plot, phase_c_plot, 'r-', 'LineWidth', 2, 'DisplayName', '校正后 G_c(s)G_0(s)');
semilogx(w_plot, phase_gc, 'g--', 'LineWidth', 1.5, 'DisplayName', '超前校正 G_c(s)');

% 标注-180°线和相位裕度
yline(-180, 'k--', 'LineWidth', 1);
xline(Wcp0, 'b:', 'LineWidth', 1);
xline(Wcp_c, 'r:', 'LineWidth', 1);

% 获取穿越频率处的相位值
phase_at_wcp0 = interp1(w_plot, phase0_plot, Wcp0);
phase_at_wcp_c = interp1(w_plot, phase_c_plot, Wcp_c);

% 标注相位裕度
plot(Wcp0, phase_at_wcp0, 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b', 'HandleVisibility', 'off');
plot(Wcp_c, phase_at_wcp_c, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'HandleVisibility', 'off');

% 添加相位裕度标注文字
text(Wcp0*1.2, phase_at_wcp0+15, sprintf('PM=%.1f°', Pm0), 'Color', 'b', 'FontSize', 9, 'FontWeight', 'bold');
text(Wcp_c*1.2, phase_at_wcp_c+15, sprintf('PM=%.1f°', Pm_c), 'Color', 'r', 'FontSize', 9, 'FontWeight', 'bold');

grid on;
xlabel('频率 \omega (rad/s)', 'FontSize', 11);
ylabel('相位 (°)', 'FontSize', 11);
title('相频特性曲线对比', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'southwest', 'FontSize', 10);
xlim([1e-1, 1e4]);
set(gca, 'FontSize', 10);

% 添加总标题
sgtitle('校正前后伯德图对比', 'FontSize', 14, 'FontWeight', 'bold');

%% 9. 绘制阶跃响应曲线 (校正前后对比)
% 构建闭环系统
T0_cl = feedback(G0, 1);  % 校正前闭环
T_c_cl = feedback(G_corrected, 1);  % 校正后闭环

figure('Name', '阶跃响应对比', 'Position', [100, 100, 800, 500]);
t = 0:0.001:3;
[y0, t0] = step(T0_cl, t);
[yc, tc] = step(T_c_cl, t);

plot(t0, y0, 'b-', 'LineWidth', 1.5);
hold on;
plot(tc, yc, 'r--', 'LineWidth', 1.5);
yline(1, 'k--', 'LineWidth', 0.5);
grid on;
xlabel('时间 (s)');
ylabel('响应');
title('单位阶跃响应曲线对比');
legend('校正前', '校正后', '稳态值', 'Location', 'southeast');

%% 10. 计算并输出阶跃响应性能指标
disp('========== 阶跃响应性能指标 ==========');

% 校正前
info0 = stepinfo(T0_cl);
fprintf('\n校正前闭环系统:\n');
fprintf('上升时间 Tr = %.4f s\n', info0.RiseTime);
fprintf('峰值时间 Tp = %.4f s\n', info0.PeakTime);
fprintf('超调量 Mp = %.4f%%\n', info0.Overshoot);
fprintf('调节时间 Ts = %.4f s (2%%准则)\n', info0.SettlingTime);

% 校正后
info_c = stepinfo(T_c_cl);
fprintf('\n校正后闭环系统:\n');
fprintf('上升时间 Tr = %.4f s\n', info_c.RiseTime);
fprintf('峰值时间 Tp = %.4f s\n', info_c.PeakTime);
fprintf('超调量 Mp = %.4f%%\n', info_c.Overshoot);
fprintf('调节时间 Ts = %.4f s (2%%准则)\n', info_c.SettlingTime);

%% 11. 输出超前校正总结
disp('==========================================');
disp('              设计结果总结                ');
disp('==========================================');
fprintf('\n原系统传递函数: G0(s) = %d / [(s+1)(0.5s+1)(0.002s+1)]\n', K);
fprintf('\n超前校正传递函数: Gc(s) = (%.4fs + 1) / (%.4fs + 1)\n', a*T, T);
fprintf('\n校正参数:\n');
fprintf('  α (超前系数) = %.4f\n', a);
fprintf('  T (时间常数) = %.6f s\n', T);
fprintf('  αT (零点时间常数) = %.6f s\n', a*T);
fprintf('  零点位置: s = %.4f rad/s\n', -1/(a*T));
fprintf('  极点位置: s = %.4f rad/s\n', -1/T);
fprintf('\n校正后系统性能:\n');
fprintf('  相位裕度: %.2f° (要求: ≥%.0f°) ✓\n', Pm_c, Pm_desired);
fprintf('  开环增益: K = %d (要求: ≥100) ✓\n', K);
