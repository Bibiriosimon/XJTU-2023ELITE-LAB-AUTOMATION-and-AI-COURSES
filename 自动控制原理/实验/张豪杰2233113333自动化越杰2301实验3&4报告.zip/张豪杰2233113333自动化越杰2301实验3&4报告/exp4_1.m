%% 实验4-1：典型环节参数变化与时域响应、频域曲线变化规律
% 通过不同参数找出变化规律

clear; clc; close all;

%% 1. 比例环节 Kp (Kp1~Kp3)
figure('Name', '比例环节', 'Position', [100, 100, 1200, 400]);

Kp_values = [1, 2, 5];  % Kp1, Kp2, Kp3
colors = {'b', 'r', 'g'};
legends_kp = {};

% 时域响应 - 阶跃响应
subplot(1,3,1);
hold on;
t = 0:0.01:5;
for i = 1:length(Kp_values)
    Kp = Kp_values(i);
    sys = tf(Kp, 1);
    [y, t_out] = step(sys, t);
    plot(t_out, y, colors{i}, 'LineWidth', 1.5);
    legends_kp{i} = sprintf('Kp = %g', Kp);
end
xlabel('时间 (s)'); ylabel('幅值');
title('比例环节 - 阶跃响应');
legend(legends_kp); grid on;

% 频域响应 - Bode图
subplot(1,3,2);
hold on;
w = logspace(-2, 2, 1000);
for i = 1:length(Kp_values)
    Kp = Kp_values(i);
    sys = tf(Kp, 1);
    [mag, phase] = bode(sys, w);
    semilogx(w, 20*log10(squeeze(mag)), colors{i}, 'LineWidth', 1.5);
end
xlabel('频率 (rad/s)'); ylabel('幅值 (dB)');
title('比例环节 - 幅频特性');
legend(legends_kp); grid on;

subplot(1,3,3);
hold on;
for i = 1:length(Kp_values)
    Kp = Kp_values(i);
    sys = tf(Kp, 1);
    [mag, phase] = bode(sys, w);
    semilogx(w, squeeze(phase), colors{i}, 'LineWidth', 1.5);
end
xlabel('频率 (rad/s)'); ylabel('相位 (度)');
title('比例环节 - 相频特性');
legend(legends_kp); grid on;

sgtitle('1. 比例环节 Kp 参数变化分析');

%% 2. 积分环节 1/(Ti*s) (Ti1~Ti3)
figure('Name', '积分环节', 'Position', [100, 100, 1200, 400]);

Ti_values = [0.5, 1, 2];  % Ti1, Ti2, Ti3
legends_ti = {};

% 时域响应 - 阶跃响应
subplot(1,3,1);
hold on;
t = 0:0.01:5;
for i = 1:length(Ti_values)
    Ti = Ti_values(i);
    sys = tf(1, [Ti, 0]);
    [y, t_out] = step(sys, t);
    plot(t_out, y, colors{i}, 'LineWidth', 1.5);
    legends_ti{i} = sprintf('Ti = %g', Ti);
end
xlabel('时间 (s)'); ylabel('幅值');
title('积分环节 - 阶跃响应');
legend(legends_ti); grid on;

% 频域响应 - Bode图
subplot(1,3,2);
hold on;
w = logspace(-2, 2, 1000);
for i = 1:length(Ti_values)
    Ti = Ti_values(i);
    sys = tf(1, [Ti, 0]);
    [mag, phase] = bode(sys, w);
    semilogx(w, 20*log10(squeeze(mag)), colors{i}, 'LineWidth', 1.5);
end
xlabel('频率 (rad/s)'); ylabel('幅值 (dB)');
title('积分环节 - 幅频特性');
legend(legends_ti); grid on;

subplot(1,3,3);
hold on;
for i = 1:length(Ti_values)
    Ti = Ti_values(i);
    sys = tf(1, [Ti, 0]);
    [mag, phase] = bode(sys, w);
    semilogx(w, squeeze(phase), colors{i}, 'LineWidth', 1.5);
end
xlabel('频率 (rad/s)'); ylabel('相位 (度)');
title('积分环节 - 相频特性');
legend(legends_ti); grid on;

sgtitle('2. 积分环节 1/(Ti·s) 参数变化分析');

%% 3. 微分环节 Td*s/(s+1) (Td1~Td3)
figure('Name', '微分环节', 'Position', [100, 100, 1200, 400]);

Td_values = [0.1, 0.5, 1];  % Td1, Td2, Td3
legends_td = {};

% 时域响应 - 阶跃响应
subplot(1,3,1);
hold on;
t = 0:0.01:5;
for i = 1:length(Td_values)
    Td = Td_values(i);
    sys = tf([Td, 0], [1, 1]);
    [y, t_out] = step(sys, t);
    plot(t_out, y, colors{i}, 'LineWidth', 1.5);
    legends_td{i} = sprintf('Td = %g', Td);
end
xlabel('时间 (s)'); ylabel('幅值');
title('微分环节 - 阶跃响应');
legend(legends_td); grid on;

% 频域响应 - Bode图
subplot(1,3,2);
hold on;
w = logspace(-2, 2, 1000);
for i = 1:length(Td_values)
    Td = Td_values(i);
    sys = tf([Td, 0], [1, 1]);
    [mag, phase] = bode(sys, w);
    semilogx(w, 20*log10(squeeze(mag)), colors{i}, 'LineWidth', 1.5);
end
xlabel('频率 (rad/s)'); ylabel('幅值 (dB)');
title('微分环节 - 幅频特性');
legend(legends_td); grid on;

subplot(1,3,3);
hold on;
for i = 1:length(Td_values)
    Td = Td_values(i);
    sys = tf([Td, 0], [1, 1]);
    [mag, phase] = bode(sys, w);
    semilogx(w, squeeze(phase), colors{i}, 'LineWidth', 1.5);
end
xlabel('频率 (rad/s)'); ylabel('相位 (度)');
title('微分环节 - 相频特性');
legend(legends_td); grid on;

sgtitle('3. 微分环节 Td·s/(s+1) 参数变化分析');

%% 4. 惯性环节 1/(Ts+1) (T1~T3)
figure('Name', '惯性环节', 'Position', [100, 100, 1200, 400]);

T_values = [0.2, 0.5, 1];  % T1, T2, T3
legends_t = {};

% 时域响应 - 阶跃响应
subplot(1,3,1);
hold on;
t = 0:0.01:5;
for i = 1:length(T_values)
    T = T_values(i);
    sys = tf(1, [T, 1]);
    [y, t_out] = step(sys, t);
    plot(t_out, y, colors{i}, 'LineWidth', 1.5);
    legends_t{i} = sprintf('T = %g', T);
end
xlabel('时间 (s)'); ylabel('幅值');
title('惯性环节 - 阶跃响应');
legend(legends_t); grid on;

% 频域响应 - Bode图
subplot(1,3,2);
hold on;
w = logspace(-2, 2, 1000);
for i = 1:length(T_values)
    T = T_values(i);
    sys = tf(1, [T, 1]);
    [mag, phase] = bode(sys, w);
    semilogx(w, 20*log10(squeeze(mag)), colors{i}, 'LineWidth', 1.5);
end
xlabel('频率 (rad/s)'); ylabel('幅值 (dB)');
title('惯性环节 - 幅频特性');
legend(legends_t); grid on;

subplot(1,3,3);
hold on;
for i = 1:length(T_values)
    T = T_values(i);
    sys = tf(1, [T, 1]);
    [mag, phase] = bode(sys, w);
    semilogx(w, squeeze(phase), colors{i}, 'LineWidth', 1.5);
end
xlabel('频率 (rad/s)'); ylabel('相位 (度)');
title('惯性环节 - 相频特性');
legend(legends_t); grid on;

sgtitle('4. 惯性环节 1/(T·s+1) 参数变化分析');

%% 5. 比例积分环节 Kp + 1/(Ti*s) (Kp1~Kp2, Ti1~Ti2)
figure('Name', '比例积分环节', 'Position', [100, 100, 1200, 800]);

Kp_pi = [1, 2];  % Kp1, Kp2
Ti_pi = [0.5, 1];  % Ti1, Ti2
colors_pi = {'b', 'r', 'g', 'm'};
legends_pi = {};

% 时域响应 - 阶跃响应
subplot(2,3,1);
hold on;
t = 0:0.01:5;
idx = 1;
for i = 1:length(Kp_pi)
    for j = 1:length(Ti_pi)
        Kp = Kp_pi(i);
        Ti = Ti_pi(j);
        % Kp + 1/(Ti*s) = (Kp*Ti*s + 1)/(Ti*s)
        sys = tf([Kp*Ti, 1], [Ti, 0]);
        [y, t_out] = step(sys, t);
        plot(t_out, y, colors_pi{idx}, 'LineWidth', 1.5);
        legends_pi{idx} = sprintf('Kp=%g, Ti=%g', Kp, Ti);
        idx = idx + 1;
    end
end
xlabel('时间 (s)'); ylabel('幅值');
title('比例积分 - 阶跃响应');
legend(legends_pi, 'Location', 'best'); grid on;

% 频域响应 - Bode图
subplot(2,3,2);
hold on;
w = logspace(-2, 2, 1000);
idx = 1;
for i = 1:length(Kp_pi)
    for j = 1:length(Ti_pi)
        Kp = Kp_pi(i);
        Ti = Ti_pi(j);
        sys = tf([Kp*Ti, 1], [Ti, 0]);
        [mag, phase] = bode(sys, w);
        semilogx(w, 20*log10(squeeze(mag)), colors_pi{idx}, 'LineWidth', 1.5);
        idx = idx + 1;
    end
end
xlabel('频率 (rad/s)'); ylabel('幅值 (dB)');
title('比例积分 - 幅频特性');
legend(legends_pi, 'Location', 'best'); grid on;

subplot(2,3,3);
hold on;
idx = 1;
for i = 1:length(Kp_pi)
    for j = 1:length(Ti_pi)
        Kp = Kp_pi(i);
        Ti = Ti_pi(j);
        sys = tf([Kp*Ti, 1], [Ti, 0]);
        [mag, phase] = bode(sys, w);
        semilogx(w, squeeze(phase), colors_pi{idx}, 'LineWidth', 1.5);
        idx = idx + 1;
    end
end
xlabel('频率 (rad/s)'); ylabel('相位 (度)');
title('比例积分 - 相频特性');
legend(legends_pi, 'Location', 'best'); grid on;

% 固定Ti，变化Kp
subplot(2,3,4);
hold on;
Ti_fixed = 1;
for i = 1:length(Kp_pi)
    Kp = Kp_pi(i);
    sys = tf([Kp*Ti_fixed, 1], [Ti_fixed, 0]);
    [y, t_out] = step(sys, t);
    plot(t_out, y, colors{i}, 'LineWidth', 1.5);
end
xlabel('时间 (s)'); ylabel('幅值');
title(sprintf('固定Ti=%g, 变化Kp', Ti_fixed));
legend(arrayfun(@(x) sprintf('Kp=%g', x), Kp_pi, 'UniformOutput', false)); grid on;

% 固定Kp，变化Ti
subplot(2,3,5);
hold on;
Kp_fixed = 1;
for j = 1:length(Ti_pi)
    Ti = Ti_pi(j);
    sys = tf([Kp_fixed*Ti, 1], [Ti, 0]);
    [y, t_out] = step(sys, t);
    plot(t_out, y, colors{j}, 'LineWidth', 1.5);
end
xlabel('时间 (s)'); ylabel('幅值');
title(sprintf('固定Kp=%g, 变化Ti', Kp_fixed));
legend(arrayfun(@(x) sprintf('Ti=%g', x), Ti_pi, 'UniformOutput', false)); grid on;

sgtitle('5. 比例积分环节 Kp + 1/(Ti·s) 参数变化分析');

%% 6. 比例微分环节 Kp + Td*s/(s+1) (Kp1~Kp2, Td1~Td2)
figure('Name', '比例微分环节', 'Position', [100, 100, 1200, 800]);

Kp_pd = [1, 2];  % Kp1, Kp2
Td_pd = [0.2, 0.5];  % Td1, Td2
colors_pd = {'b', 'r', 'g', 'm'};
legends_pd = {};

% 时域响应 - 阶跃响应
subplot(2,3,1);
hold on;
t = 0:0.01:5;
idx = 1;
for i = 1:length(Kp_pd)
    for j = 1:length(Td_pd)
        Kp = Kp_pd(i);
        Td = Td_pd(j);
        % Kp + Td*s/(s+1) = (Kp*(s+1) + Td*s)/(s+1) = ((Kp+Td)*s + Kp)/(s+1)
        sys = tf([Kp+Td, Kp], [1, 1]);
        [y, t_out] = step(sys, t);
        plot(t_out, y, colors_pd{idx}, 'LineWidth', 1.5);
        legends_pd{idx} = sprintf('Kp=%g, Td=%g', Kp, Td);
        idx = idx + 1;
    end
end
xlabel('时间 (s)'); ylabel('幅值');
title('比例微分 - 阶跃响应');
legend(legends_pd, 'Location', 'best'); grid on;

% 频域响应 - Bode图
subplot(2,3,2);
hold on;
w = logspace(-2, 2, 1000);
idx = 1;
for i = 1:length(Kp_pd)
    for j = 1:length(Td_pd)
        Kp = Kp_pd(i);
        Td = Td_pd(j);
        sys = tf([Kp+Td, Kp], [1, 1]);
        [mag, phase] = bode(sys, w);
        semilogx(w, 20*log10(squeeze(mag)), colors_pd{idx}, 'LineWidth', 1.5);
        idx = idx + 1;
    end
end
xlabel('频率 (rad/s)'); ylabel('幅值 (dB)');
title('比例微分 - 幅频特性');
legend(legends_pd, 'Location', 'best'); grid on;

subplot(2,3,3);
hold on;
idx = 1;
for i = 1:length(Kp_pd)
    for j = 1:length(Td_pd)
        Kp = Kp_pd(i);
        Td = Td_pd(j);
        sys = tf([Kp+Td, Kp], [1, 1]);
        [mag, phase] = bode(sys, w);
        semilogx(w, squeeze(phase), colors_pd{idx}, 'LineWidth', 1.5);
        idx = idx + 1;
    end
end
xlabel('频率 (rad/s)'); ylabel('相位 (度)');
title('比例微分 - 相频特性');
legend(legends_pd, 'Location', 'best'); grid on;

% 固定Td，变化Kp
subplot(2,3,4);
hold on;
Td_fixed = 0.5;
for i = 1:length(Kp_pd)
    Kp = Kp_pd(i);
    sys = tf([Kp+Td_fixed, Kp], [1, 1]);
    [y, t_out] = step(sys, t);
    plot(t_out, y, colors{i}, 'LineWidth', 1.5);
end
xlabel('时间 (s)'); ylabel('幅值');
title(sprintf('固定Td=%g, 变化Kp', Td_fixed));
legend(arrayfun(@(x) sprintf('Kp=%g', x), Kp_pd, 'UniformOutput', false)); grid on;

% 固定Kp，变化Td
subplot(2,3,5);
hold on;
Kp_fixed = 1;
for j = 1:length(Td_pd)
    Td = Td_pd(j);
    sys = tf([Kp_fixed+Td, Kp_fixed], [1, 1]);
    [y, t_out] = step(sys, t);
    plot(t_out, y, colors{j}, 'LineWidth', 1.5);
end
xlabel('时间 (s)'); ylabel('幅值');
title(sprintf('固定Kp=%g, 变化Td', Kp_fixed));
legend(arrayfun(@(x) sprintf('Td=%g', x), Td_pd, 'UniformOutput', false)); grid on;

sgtitle('6. 比例微分环节 Kp + Td·s/(s+1) 参数变化分析');

%% 打印参数变化规律总结
fprintf('\n============================================\n');
fprintf('        各环节参数变化规律总结\n');
fprintf('============================================\n\n');

fprintf('1. 比例环节 Kp:\n');
fprintf('   时域: Kp增大，输出幅值成比例增大，无动态过程\n');
fprintf('   频域: 幅频曲线平行上移(+20lgKp dB)，相频恒为0°\n\n');

fprintf('2. 积分环节 1/(Ti·s):\n');
fprintf('   时域: Ti减小，积分速度加快，斜率增大\n');
fprintf('   频域: 幅频斜率-20dB/dec，Ti减小曲线上移；相频恒为-90°\n\n');

fprintf('3. 微分环节 Td·s/(s+1):\n');
fprintf('   时域: Td增大，初始脉冲幅值增大，衰减变慢\n');
fprintf('   频域: 高频增益增大，相位超前增加\n\n');

fprintf('4. 惯性环节 1/(Ts+1):\n');
fprintf('   时域: T增大，响应变慢，上升时间增加\n');
fprintf('   频域: 转折频率1/T，T增大带宽减小，相位滞后增加\n\n');

fprintf('5. 比例积分 Kp + 1/(Ti·s):\n');
fprintf('   时域: Kp影响比例作用强度，Ti影响积分速度\n');
fprintf('   频域: 低频积分特性(-90°)，高频趋于比例(0°)\n\n');

fprintf('6. 比例微分 Kp + Td·s/(s+1):\n');
fprintf('   时域: Kp决定稳态值，Td影响超调和响应速度\n');
fprintf('   频域: 低频趋于比例，高频相位超前\n\n');

fprintf('============================================\n');
