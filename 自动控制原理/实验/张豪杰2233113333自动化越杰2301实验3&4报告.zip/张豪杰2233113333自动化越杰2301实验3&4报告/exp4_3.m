%% 实验4-3: 大延迟系统PID控制与Smith预估器
% 系统: G(s) = 22/(50s+1) * e^(-20s)
% 内容: 动态特性参数法、科恩-库恩整定法设计PID，Smith预估器

clear; clc; close all;

%% 系统参数
K = 22;         % 系统增益
T = 50;         % 时间常数
tau = 20;       % 延迟时间
s = tf('s');

% 原系统（无延迟部分）
G0 = K / (T*s + 1);

% 带延迟的原系统
G = G0 * exp(-tau*s);   % 使用pade近似会在后面处理

% 使用pade近似延迟环节(3阶)
[num_delay, den_delay] = pade(tau, 3);
G_delay = tf(num_delay, den_delay);
G_pade = G0 * G_delay;  % 近似后的系统

%% 方法1: 动态特性参数法
% 基于一阶加纯滞后模型 G(s) = K*e^(-tau*s)/(Ts+1)
% 利用系统动态特性参数K、T、tau直接计算PID参数

fprintf('========== 动态特性参数法 ==========\n');
fprintf('系统参数: K=%.1f, T=%.1f, tau=%.1f\n', K, T, tau);
fprintf('延迟比 tau/T = %.4f\n', tau/T);

% 动态特性参数法PID参数公式
% 基于一阶惯性加纯滞后系统的经验公式
Kp_DY = (0.9*T + 0.5*tau) / (K * tau);
Ti_DY = tau * (30*T + 3*tau) / (9*T + 20*tau);
Td_DY = 0.5 * tau * T / (0.3*T + tau);

Ki_DY = Kp_DY / Ti_DY;
Kd_DY = Kp_DY * Td_DY;

fprintf('\n动态特性参数法整定参数:\n');
fprintf('Kp = %.4f\n', Kp_DY);
fprintf('Ti = %.4f, Ki = %.4f\n', Ti_DY, Ki_DY);
fprintf('Td = %.4f, Kd = %.4f\n', Td_DY, Kd_DY);

% 动态特性参数法的PID控制器: Gc(s) = Kp(1 + 1/(Ti*s) + Td*s)
Gc_DY = Kp_DY * (1 + 1/(Ti_DY*s) + Td_DY*s);
% 或者标准形式: Gc(s) = Kp + Ki/s + Kd*s
Gc_DY_standard = Kp_DY + Ki_DY/s + Kd_DY*s;

%% 方法2: 科恩-库恩整定法 (Cohen-Coon)
fprintf('\n========== 科恩-库恩整定法 (Cohen-Coon) ==========\n');

% Cohen-Coon方法参数
r = tau / T;  % 延迟比
fprintf('延迟比 r = tau/T = %.4f\n', r);

% Cohen-Coon PID参数公式
Kp_CC = (1/K) * (T/tau) * (4/3 + tau/(4*T));
Ti_CC = tau * (32 + 6*tau/T) / (13 + 8*tau/T);
Td_CC = tau * 4 / (11 + 2*tau/T);

Ki_CC = Kp_CC / Ti_CC;
Kd_CC = Kp_CC * Td_CC;

fprintf('\nCohen-Coon整定参数:\n');
fprintf('Kp = %.4f\n', Kp_CC);
fprintf('Ti = %.4f, Ki = %.4f\n', Ti_CC, Ki_CC);
fprintf('Td = %.4f, Kd = %.4f\n', Td_CC, Kd_CC);

% Cohen-Coon方法的PID控制器
Gc_CC = Kp_CC * (1 + 1/(Ti_CC*s) + Td_CC*s);

%% 构建闭环系统
% 原开环系统(使用pade近似)
sys_open = G_pade;

% 动态特性参数法闭环系统
sys_DY_open = Gc_DY * G_pade;
sys_DY_closed = feedback(sys_DY_open, 1);

% Cohen-Coon方法闭环系统
sys_CC_open = Gc_CC * G_pade;
sys_CC_closed = feedback(sys_CC_open, 1);

%% 方法3: Smith预估器
fprintf('\n========== Smith预估器设计 ==========\n');

% Smith预估器原理:
% 将系统分解为 G(s) = G0(s) * e^(-tau*s)
% Smith预估器消除延迟对闭环特性的影响

% 使用动态特性参数法PID + Smith预估器
% Smith预估器结构: 在PID后加入 G0(s)(1-e^(-tau*s)) 的补偿

% 构建Smith预估器补偿环节
% Gm(s) = G0(s) - G0(s)*e^(-tau*s) = G0(s)*(1 - e^(-tau*s))
G0_delay = G0 * G_delay;  % G0(s)*e^(-tau*s) 近似
Gm = G0 - G0_delay;       % Smith预估器模型

% Smith预估器闭环传递函数
% 等效开环传递函数(理想情况下消除延迟影响)
% T(s) = Gc(s)*G(s) / (1 + Gc(s)*Gm(s))
% 闭环: T_closed(s) = T(s) / (1 + T(s))

% 动态特性参数法 + Smith预估器
numerator_DY = Gc_DY * G_pade;
denominator_DY = 1 + Gc_DY * Gm;
sys_DY_Smith_equiv = numerator_DY / denominator_DY;
sys_DY_Smith_closed = feedback(sys_DY_Smith_equiv, 1);

% Cohen-Coon + Smith预估器
numerator_CC = Gc_CC * G_pade;
denominator_CC = 1 + Gc_CC * Gm;
sys_CC_Smith_equiv = numerator_CC / denominator_CC;
sys_CC_Smith_closed = feedback(sys_CC_Smith_equiv, 1);

% 简化的Smith预估器设计（直接消除延迟后设计）
% 理想Smith预估器等效系统（无延迟）
sys_DY_ideal = feedback(Gc_DY * G0, 1);
sys_CC_ideal = feedback(Gc_CC * G0, 1);

fprintf('Smith预估器设计完成\n');
fprintf('预估器模型: Gm(s) = G0(s)*(1 - e^(-tau*s))\n');

%% 绘图1: 原系统与PID控制对比
figure('Name', '原系统与PID控制阶跃响应对比', 'Position', [100, 100, 1000, 600]);

t = 0:0.1:500;  % 仿真时间

% 原系统阶跃响应
subplot(2,2,1);
[y_open, t_open] = step(sys_open, t);
plot(t_open, y_open, 'b-', 'LineWidth', 1.5);
hold on;
yline(1, 'k--', 'LineWidth', 1);
xlabel('时间 (s)');
ylabel('输出');
title('原系统（无控制器）阶跃响应');
legend('原系统', '参考值', 'Location', 'best');
grid on;

% 动态特性参数法PID控制
subplot(2,2,2);
[y_DY, t_DY] = step(sys_DY_closed, t);
plot(t_DY, y_DY, 'r-', 'LineWidth', 1.5);
hold on;
yline(1, 'k--', 'LineWidth', 1);
xlabel('时间 (s)');
ylabel('输出');
title('动态特性参数法PID控制');
legend('动态特性法 PID', '参考值', 'Location', 'best');
grid on;

% Cohen-Coon方法PID控制
subplot(2,2,3);
[y_CC, t_CC] = step(sys_CC_closed, t);
plot(t_CC, y_CC, 'g-', 'LineWidth', 1.5);
hold on;
yline(1, 'k--', 'LineWidth', 1);
xlabel('时间 (s)');
ylabel('输出');
title('Cohen-Coon整定法PID控制');
legend('C-C PID', '参考值', 'Location', 'best');
grid on;

% 对比图
subplot(2,2,4);
plot(t_DY, y_DY, 'r-', 'LineWidth', 1.5);
hold on;
plot(t_CC, y_CC, 'g-', 'LineWidth', 1.5);
yline(1, 'k--', 'LineWidth', 1);
xlabel('时间 (s)');
ylabel('输出');
title('三种情况对比');
legend('动态特性法 PID', 'C-C PID', '参考值', 'Location', 'best');
grid on;

sgtitle('大延迟系统PID控制效果对比');

%% 绘图2: Smith预估器效果对比
figure('Name', 'Smith预估器控制效果', 'Position', [150, 150, 1000, 600]);

% 动态特性法 PID vs 动态特性法 PID + Smith
subplot(2,2,1);
plot(t_DY, y_DY, 'r-', 'LineWidth', 1.5);
hold on;
[y_DY_Smith, t_DY_Smith] = step(sys_DY_Smith_closed, t);
plot(t_DY_Smith, y_DY_Smith, 'r--', 'LineWidth', 1.5);
yline(1, 'k--', 'LineWidth', 1);
xlabel('时间 (s)');
ylabel('输出');
title('动态特性法PID vs 动态特性法PID + Smith预估器');
legend('动态特性法 PID', '动态特性法 + Smith', '参考值', 'Location', 'best');
grid on;

% Cohen-Coon PID vs Cohen-Coon PID + Smith
subplot(2,2,2);
plot(t_CC, y_CC, 'g-', 'LineWidth', 1.5);
hold on;
[y_CC_Smith, t_CC_Smith] = step(sys_CC_Smith_closed, t);
plot(t_CC_Smith, y_CC_Smith, 'g--', 'LineWidth', 1.5);
yline(1, 'k--', 'LineWidth', 1);
xlabel('时间 (s)');
ylabel('输出');
title('C-C PID控制 vs C-C PID + Smith预估器');
legend('C-C PID', 'C-C PID + Smith', '参考值', 'Location', 'best');
grid on;

% 所有方法对比
subplot(2,2,[3,4]);
plot(t_DY, y_DY, 'r-', 'LineWidth', 1.5);
hold on;
plot(t_CC, y_CC, 'g-', 'LineWidth', 1.5);
plot(t_DY_Smith, y_DY_Smith, 'r--', 'LineWidth', 1.5);
plot(t_CC_Smith, y_CC_Smith, 'g--', 'LineWidth', 1.5);
yline(1, 'k--', 'LineWidth', 1);
xlabel('时间 (s)');
ylabel('输出');
title('所有控制方法对比');
legend('动态特性法 PID', 'C-C PID', '动态特性法 + Smith', 'C-C + Smith', '参考值', 'Location', 'best');
grid on;

sgtitle('Smith预估器控制效果对比');

%% 性能指标分析
fprintf('\n========== 性能指标分析 ==========\n');

% 计算性能指标函数
analyze_performance = @(y, t, name) analyze_step_response(y, t, name);

fprintf('\n--- 原系统 ---\n');
analyze_performance(y_open, t_open, '原系统');

fprintf('\n--- 动态特性参数法PID控制 ---\n');
analyze_performance(y_DY, t_DY, '动态特性法 PID');

fprintf('\n--- Cohen-Coon PID控制 ---\n');
analyze_performance(y_CC, t_CC, 'C-C PID');

fprintf('\n--- 动态特性参数法PID + Smith预估器 ---\n');
analyze_performance(y_DY_Smith, t_DY_Smith, '动态特性法 + Smith');

fprintf('\n--- Cohen-Coon PID + Smith预估器 ---\n');
analyze_performance(y_CC_Smith, t_CC_Smith, 'C-C + Smith');

%% 两种PID整定方法特点对比
fprintf('\n========== 两种PID整定方法特点对比 ==========\n');
fprintf('\n1. 动态特性参数法:\n');
fprintf('   - 基于系统的增益K、时间常数T和延迟时间tau\n');
fprintf('   - 利用一阶惯性加纯滞后系统的动态特性\n');
fprintf('   - 公式: Kp=(0.9T+0.5tau)/(K*tau)\n');
fprintf('   - Ti=tau*(30T+3tau)/(9T+20tau), Td=0.5*tau*T/(0.3T+tau)\n');
fprintf('   - 适用于一阶加纯滞后系统的PID整定\n');

fprintf('\n2. 科恩-库恩整定法 (Cohen-Coon):\n');
fprintf('   - 考虑了延迟比r=tau/T的影响\n');
fprintf('   - 对大延迟系统有更好的适应性\n');
fprintf('   - 超调量相对较小，稳定性较好\n');
fprintf('   - 适用于延迟占主导的过程控制\n');

fprintf('\n========== Smith预估器作用说明 ==========\n');
fprintf('1. Smith预估器通过建立过程模型来补偿纯延迟的影响\n');
fprintf('2. 理想情况下，可将延迟环节从闭环特征方程中消除\n');
fprintf('3. 等效于对无延迟系统进行控制，大大改善系统动态性能\n');
fprintf('4. 可以显著减小超调量和调节时间\n');
fprintf('5. 对模型精度有一定要求，模型失配会影响控制效果\n');

%% 性能分析函数
function analyze_step_response(y, t, name)
    % 稳态值
    y_ss = y(end);
    fprintf('%s - 稳态值: %.4f\n', name, y_ss);
    
    % 上升时间 (10%到90%)
    y_10 = 0.1 * y_ss;
    y_90 = 0.9 * y_ss;
    idx_10 = find(y >= y_10, 1, 'first');
    idx_90 = find(y >= y_90, 1, 'first');
    if ~isempty(idx_10) && ~isempty(idx_90) && idx_90 > idx_10
        tr = t(idx_90) - t(idx_10);
        fprintf('%s - 上升时间: %.2f s\n', name, tr);
    else
        fprintf('%s - 上升时间: 无法计算\n', name);
    end
    
    % 峰值时间和超调量
    [y_max, idx_max] = max(y);
    tp = t(idx_max);
    if y_ss > 0.01
        overshoot = (y_max - y_ss) / y_ss * 100;
    else
        overshoot = 0;
    end
    fprintf('%s - 峰值时间: %.2f s\n', name, tp);
    fprintf('%s - 超调量: %.2f%%\n', name, max(0, overshoot));
    
    % 调节时间 (2%误差带)
    error_band = 0.02 * y_ss;
    idx_settle = find(abs(y - y_ss) > error_band, 1, 'last');
    if ~isempty(idx_settle) && idx_settle < length(t)
        ts = t(idx_settle + 1);
        fprintf('%s - 调节时间(2%%): %.2f s\n', name, ts);
    else
        fprintf('%s - 调节时间(2%%): >%.0f s\n', name, t(end));
    end
end
