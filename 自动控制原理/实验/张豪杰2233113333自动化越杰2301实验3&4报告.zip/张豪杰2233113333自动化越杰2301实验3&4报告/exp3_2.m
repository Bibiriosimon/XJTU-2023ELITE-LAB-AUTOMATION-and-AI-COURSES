%% 实验3.2 滞后校正传递函数设计
% 已知单位负反馈系统被控对象的开环传递函数为 G(s) = K / [(s+1)(0.2s+1)(0.3s+1)]
% 设计滞后校正传递函数
% 要求: K >= 20, 幅值裕度 > 10dB, 相位裕度 > 45°, 穿越频率 wc >= 2.1 rad/s

clear; clc; close all;

%% 1. 定义原系统参数
K = 20;  % 开环增益

% 原系统传递函数 G(s) = K / [(s+1)(0.2s+1)(0.3s+1)]
num0 = K;
den0 = conv(conv([1 1], [0.2 1]), [0.3 1]);  % 展开分母多项式

G0 = tf(num0, den0);  % 原开环传递函数

disp('========== 原系统开环传递函数 ==========');
G0

%% 2. 分析原系统的频率特性
[Gm0, Pm0, Wcg0, Wcp0] = margin(G0);

disp('========== 原系统性能指标 ==========');
fprintf('原系统幅值裕度 Gm = %.4f dB\n', 20*log10(Gm0));
fprintf('原系统相位裕度 Pm = %.4f°\n', Pm0);
fprintf('原系统幅值穿越频率 Wcg = %.4f rad/s\n', Wcg0);
fprintf('原系统相位穿越频率 Wcp = %.4f rad/s\n', Wcp0);

%% 3. 设计滞后校正环节
% 滞后校正传递函数形式: Gc(s) = (bTs + 1) / (Ts + 1), 其中 0 < b < 1
% 滞后校正的作用: 降低高频增益，同时保持低频增益不变

% 设计步骤:
% (1) 确定所需的相位裕度和穿越频率
Pm_desired = 45;      % 期望相位裕度 (度)
Gm_desired = 10;      % 期望幅值裕度 (dB)
wc_desired = 2.1;     % 期望穿越频率 (rad/s)

disp('========== 滞后校正设计 ==========');

% (2) 确定新的穿越频率 wc_new
% 选择新的穿越频率，使得在该频率处原系统的相位满足相位裕度要求
% 在新穿越频率处，相位应为: -180° + Pm_desired + 安全裕量(5-12°)
epsilon = 8;  % 滞后校正的相位滞后补偿（滞后校正在穿越频率处会带来少量相位滞后）
target_phase = -180 + Pm_desired + epsilon;

fprintf('目标相位 = %.4f°\n', target_phase);

% 通过数值方法找到相位等于目标相位的频率
w = logspace(-2, 3, 10000);
[mag0, phase0] = bode(G0, w);
mag0 = squeeze(mag0);
phase0 = squeeze(phase0);
mag0_dB = 20*log10(mag0);

% 找到相位等于目标相位的频率点
[~, idx] = min(abs(phase0 - target_phase));
wc_new = w(idx);

% 确保穿越频率满足要求
if wc_new < wc_desired
    wc_new = wc_desired;
    fprintf('警告: 调整穿越频率以满足 wc >= %.1f rad/s 的要求\n', wc_desired);
end

fprintf('新的穿越频率 wc_new = %.4f rad/s\n', wc_new);

% (3) 计算在新穿越频率处原系统的增益
[mag_at_wc, ~] = bode(G0, wc_new);
mag_at_wc = squeeze(mag_at_wc);
mag_at_wc_dB = 20*log10(mag_at_wc);

fprintf('原系统在 wc_new 处的增益 = %.4f dB\n', mag_at_wc_dB);

% (4) 计算滞后校正参数 b
% 滞后校正需要在 wc_new 处将增益降为 0 dB
% 滞后校正在高频的增益为 b (即 20*log10(b) dB)
% 需要: mag_at_wc_dB + 20*log10(b) = 0
% 解得: b = 10^(-mag_at_wc_dB/20)
b = 10^(-mag_at_wc_dB/20);

fprintf('滞后校正参数 b = %.4f\n', b);

% (5) 计算时间常数 T
% 滞后校正的零点频率 1/(bT) 应该远小于 wc_new（通常为 wc_new 的 1/5 到 1/10）
% 这样可以保证滞后校正在穿越频率处的相位滞后很小
factor = 10;  % 零点频率为 wc_new 的 1/factor
T = factor / (b * wc_new);

fprintf('滞后校正时间常数 T = %.6f s\n', T);
fprintf('滞后校正零点时间常数 bT = %.6f s\n', b*T);
fprintf('零点频率 1/(bT) = %.4f rad/s\n', 1/(b*T));
fprintf('极点频率 1/T = %.4f rad/s\n', 1/T);

%% 4. 构建滞后校正传递函数
% Gc(s) = (bTs + 1) / (Ts + 1)
num_c = [b*T 1];
den_c = [T 1];

Gc = tf(num_c, den_c);

disp('========== 滞后校正传递函数 ==========');
fprintf('Gc(s) = (%.6f*s + 1) / (%.6f*s + 1)\n', b*T, T);
Gc

%% 5. 计算校正后的开环传递函数
G_corrected = Gc * G0;

disp('========== 校正后开环传递函数 ==========');
G_corrected

%% 6. 验证校正后系统的性能
[Gm_c, Pm_c, Wcg_c, Wcp_c] = margin(G_corrected);

disp('========== 校正后系统性能指标 ==========');
fprintf('校正后幅值裕度 Gm = %.4f dB\n', 20*log10(Gm_c));
fprintf('校正后相位裕度 Pm = %.4f°\n', Pm_c);
fprintf('校正后幅值穿越频率 Wcg = %.4f rad/s\n', Wcg_c);
fprintf('校正后相位穿越频率 Wcp = %.4f rad/s\n', Wcp_c);

%% 7. 验证是否满足要求
disp('========== 验证结果 ==========');

% 验证相位裕度
if Pm_c > Pm_desired
    fprintf('√ 相位裕度满足要求: %.4f° > %.4f°\n', Pm_c, Pm_desired);
else
    fprintf('× 相位裕度不满足要求: %.4f° <= %.4f°\n', Pm_c, Pm_desired);
end

% 验证幅值裕度
if 20*log10(Gm_c) > Gm_desired
    fprintf('√ 幅值裕度满足要求: %.4f dB > %.4f dB\n', 20*log10(Gm_c), Gm_desired);
else
    fprintf('× 幅值裕度不满足要求: %.4f dB <= %.4f dB\n', 20*log10(Gm_c), Gm_desired);
end

% 验证穿越频率
if Wcp_c >= wc_desired
    fprintf('√ 穿越频率满足要求: %.4f rad/s >= %.4f rad/s\n', Wcp_c, wc_desired);
else
    fprintf('× 穿越频率不满足要求: %.4f rad/s < %.4f rad/s\n', Wcp_c, wc_desired);
end

% 验证开环增益
if K >= 20
    fprintf('√ 开环增益满足要求: K = %d >= 20\n', K);
else
    fprintf('× 开环增益不满足要求: K = %d < 20\n', K);
end

%% 8. 绘制伯德图 (校正前后对比，显示在同一张图上)
figure('Name', '校正前后伯德图对比', 'Position', [100, 100, 1000, 700]);

% 获取伯德图数据
[mag0_plot, phase0_plot, w_plot] = bode(G0, w);
mag0_plot = squeeze(mag0_plot);
phase0_plot = squeeze(phase0_plot);

[mag_c_plot, phase_c_plot] = bode(G_corrected, w);
mag_c_plot = squeeze(mag_c_plot);
phase_c_plot = squeeze(phase_c_plot);

[mag_gc, phase_gc] = bode(Gc, w);
mag_gc = squeeze(mag_gc);
phase_gc = squeeze(phase_gc);

% 幅频特性曲线
subplot(2,1,1);
semilogx(w_plot, 20*log10(mag0_plot), 'b-', 'LineWidth', 2, 'DisplayName', '校正前 G_0(s)');
hold on;
semilogx(w_plot, 20*log10(mag_c_plot), 'r-', 'LineWidth', 2, 'DisplayName', '校正后 G_c(s)G_0(s)');
semilogx(w_plot, 20*log10(mag_gc), 'g--', 'LineWidth', 1.5, 'DisplayName', '滞后校正 G_c(s)');

% 标注穿越频率
xline(Wcp0, 'b:', 'LineWidth', 1);
xline(Wcp_c, 'r:', 'LineWidth', 1);
yline(0, 'k--', 'LineWidth', 1);

% 标注穿越频率点
plot(Wcp0, 0, 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b', 'HandleVisibility', 'off');
plot(Wcp_c, 0, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'HandleVisibility', 'off');

grid on;
xlabel('频率 \omega (rad/s)', 'FontSize', 11);
ylabel('幅值 (dB)', 'FontSize', 11);
title('幅频特性曲线对比', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'southwest', 'FontSize', 10);
xlim([1e-2, 1e2]);
set(gca, 'FontSize', 10);

% 相频特性曲线
subplot(2,1,2);
semilogx(w_plot, phase0_plot, 'b-', 'LineWidth', 2, 'DisplayName', '校正前 G_0(s)');
hold on;
semilogx(w_plot, phase_c_plot, 'r-', 'LineWidth', 2, 'DisplayName', '校正后 G_c(s)G_0(s)');
semilogx(w_plot, phase_gc, 'g--', 'LineWidth', 1.5, 'DisplayName', '滞后校正 G_c(s)');

% 标注-180°线和相位裕度
yline(-180, 'k--', 'LineWidth', 1);
xline(Wcp0, 'b:', 'LineWidth', 1);
xline(Wcp_c, 'r:', 'LineWidth', 1);

% 获取穿越频率处的相位值
phase_at_wcp0 = interp1(w_plot, phase0_plot, Wcp0);
phase_at_wcp_c = interp1(w_plot, phase_c_plot, Wcp_c);

% 标注相位裕度
plot(Wcp0, phase_at_wcp0, 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b', 'HandleVisibility', 'off');
plot(Wcp_c, phase_at_wcp_c, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'HandleVisibility', 'off');

% 添加相位裕度标注文字
text(Wcp0*1.2, phase_at_wcp0+10, sprintf('PM=%.1f°', Pm0), 'Color', 'b', 'FontSize', 9, 'FontWeight', 'bold');
text(Wcp_c*1.2, phase_at_wcp_c+10, sprintf('PM=%.1f°', Pm_c), 'Color', 'r', 'FontSize', 9, 'FontWeight', 'bold');

grid on;
xlabel('频率 \omega (rad/s)', 'FontSize', 11);
ylabel('相位 (°)', 'FontSize', 11);
title('相频特性曲线对比', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'southwest', 'FontSize', 10);
xlim([1e-2, 1e2]);
set(gca, 'FontSize', 10);

% 添加总标题
sgtitle('滞后校正前后伯德图对比', 'FontSize', 14, 'FontWeight', 'bold');

%% 9. 绘制阶跃响应曲线 (校正前后对比)
% 构建闭环系统
T0_cl = feedback(G0, 1);  % 校正前闭环
T_c_cl = feedback(G_corrected, 1);  % 校正后闭环

figure('Name', '阶跃响应对比', 'Position', [100, 100, 800, 500]);
t = 0:0.01:15;
[y0, t0] = step(T0_cl, t);
[yc, tc] = step(T_c_cl, t);

plot(t0, y0, 'b-', 'LineWidth', 2);
hold on;
plot(tc, yc, 'r--', 'LineWidth', 2);
yline(1, 'k--', 'LineWidth', 0.5);
grid on;
xlabel('时间 (s)', 'FontSize', 11);
ylabel('响应', 'FontSize', 11);
title('单位阶跃响应曲线对比', 'FontSize', 12, 'FontWeight', 'bold');
legend('校正前', '校正后', '稳态值', 'Location', 'southeast', 'FontSize', 10);

%% 10. 计算并输出阶跃响应性能指标
disp('========== 阶跃响应性能指标 ==========');

% 校正前
info0 = stepinfo(T0_cl);
fprintf('\n校正前闭环系统:\n');
fprintf('上升时间 Tr = %.4f s\n', info0.RiseTime);
fprintf('峰值时间 Tp = %.4f s\n', info0.PeakTime);
fprintf('超调量 Mp = %.4f%%\n', info0.Overshoot);
fprintf('调节时间 Ts = %.4f s (2%%准则)\n', info0.SettlingTime);

% 校正后
info_c = stepinfo(T_c_cl);
fprintf('\n校正后闭环系统:\n');
fprintf('上升时间 Tr = %.4f s\n', info_c.RiseTime);
fprintf('峰值时间 Tp = %.4f s\n', info_c.PeakTime);
fprintf('超调量 Mp = %.4f%%\n', info_c.Overshoot);
fprintf('调节时间 Ts = %.4f s (2%%准则)\n', info_c.SettlingTime);

%% 11. 输出滞后校正总结
disp('==========================================');
disp('              设计结果总结                ');
disp('==========================================');
fprintf('\n原系统传递函数: G0(s) = %d / [(s+1)(0.2s+1)(0.3s+1)]\n', K);
fprintf('\n滞后校正传递函数: Gc(s) = (%.4fs + 1) / (%.4fs + 1)\n', b*T, T);
fprintf('\n校正参数:\n');
fprintf('  β (滞后系数) = %.4f\n', b);
fprintf('  T (时间常数) = %.6f s\n', T);
fprintf('  βT (零点时间常数) = %.6f s\n', b*T);
fprintf('  零点位置: s = %.4f (频率 1/(βT) = %.4f rad/s)\n', -1/(b*T), 1/(b*T));
fprintf('  极点位置: s = %.4f (频率 1/T = %.4f rad/s)\n', -1/T, 1/T);
fprintf('\n校正后系统性能:\n');
fprintf('  相位裕度: %.2f° (要求: >%.0f°) ', Pm_c, Pm_desired);
if Pm_c > Pm_desired
    fprintf('✓\n');
else
    fprintf('✗\n');
end
fprintf('  幅值裕度: %.2f dB (要求: >%.0f dB) ', 20*log10(Gm_c), Gm_desired);
if 20*log10(Gm_c) > Gm_desired
    fprintf('✓\n');
else
    fprintf('✗\n');
end
fprintf('  穿越频率: %.2f rad/s (要求: ≥%.1f rad/s) ', Wcp_c, wc_desired);
if Wcp_c >= wc_desired
    fprintf('✓\n');
else
    fprintf('✗\n');
end
fprintf('  开环增益: K = %d (要求: ≥20) ✓\n', K);
