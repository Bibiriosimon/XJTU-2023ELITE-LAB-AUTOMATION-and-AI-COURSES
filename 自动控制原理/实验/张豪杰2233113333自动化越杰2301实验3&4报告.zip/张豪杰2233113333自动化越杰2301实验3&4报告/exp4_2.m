%% 实验4-2：PID控制参数设计
% 被控对象: G(s) = 120 / (s^3 + 12s^2 + 20s + 5)
% 方法: 衰减法(4:1)、比例度法、试凑法
% 绘制原系统和P/PI/PID控制的阶跃响应曲线

clear; clc; close all;

%% 定义被控对象传递函数
num = 120;
den = [1, 12, 20, 5];
Gp = tf(num, den);

fprintf('被控对象传递函数:\n');
fprintf('G(s) = 120 / (s^3 + 12s^2 + 20s + 5)\n\n');

%% 原系统开环和闭环响应分析
figure('Name', '原系统分析', 'Position', [100, 100, 1000, 400]);

subplot(1,2,1);
step(Gp);
title('原系统开环阶跃响应');
grid on;

% 原系统单位反馈闭环
Gc_original = feedback(Gp, 1);
subplot(1,2,2);
step(Gc_original);
title('原系统闭环阶跃响应(单位反馈)');
grid on;

sgtitle('原系统响应分析');

%% ==================== 方法一：衰减曲线法 (4:1) ====================
fprintf('==========================================\n');
fprintf('方法一：衰减曲线法 (4:1 衰减比)\n');
fprintf('==========================================\n\n');

% 衰减曲线法步骤：
% 1. 令Ti=∞, Td=0，即纯比例控制
% 2. 从小到大调节Kp，直到获得4:1衰减比的响应
% 3. 记录此时的Kp为Ks，振荡周期为Ts
% 4. 根据经验公式计算PI和PID参数

% 通过仿真寻找4:1衰减比对应的Kp
% 4:1衰减比意味着第二个超调峰值是第一个的1/4

Kp_test = linspace(0.01, 2, 200);
Ks_41 = 0;
Ts_41 = 0;

for i = 1:length(Kp_test)
    Kp = Kp_test(i);
    Gc_p = tf(Kp, 1);
    sys_cl = feedback(Gc_p * Gp, 1);
    
    % 检查稳定性
    poles = pole(sys_cl);
    if any(real(poles) > 0)
        continue;
    end
    
    t = 0:0.01:50;
    [y, t_out] = step(sys_cl, t);
    
    % 寻找峰值
    [peaks, locs] = findpeaks(y);
    
    if length(peaks) >= 2
        ratio = peaks(1) / peaks(2);
        % 寻找接近4:1衰减比的Kp
        if abs(ratio - 4) < 0.5
            Ks_41 = Kp;
            % 计算振荡周期
            Ts_41 = (t_out(locs(2)) - t_out(locs(1)));
            break;
        end
    end
end

% 如果没找到精确的4:1，使用近似值
if Ks_41 == 0
    % 使用临界比例度法的近似方法
    % 先找临界增益Ku
    Ku = 0;
    for Kp = linspace(0.01, 5, 500)
        Gc_p = tf(Kp, 1);
        sys_cl = feedback(Gc_p * Gp, 1);
        poles = pole(sys_cl);
        if any(real(poles) > 0)
            Ku = Kp;
            break;
        end
    end
    % 4:1衰减法的Ks约为0.5*Ku
    Ks_41 = 0.5 * Ku;
    Ts_41 = 2;  % 估计周期
end

fprintf('4:1衰减法参数:\n');
fprintf('Ks (临界比例增益) = %.4f\n', Ks_41);
fprintf('Ts (振荡周期) = %.4f s\n\n', Ts_41);

% 4:1衰减曲线法经验公式
% P控制:   Kp = Ks
% PI控制:  Kp = 0.85*Ks, Ti = Ts/2
% PID控制: Kp = 1.2*Ks, Ti = 0.5*Ts, Td = 0.125*Ts

Kp_P_41 = Ks_41;
Kp_PI_41 = 0.85 * Ks_41;
Ti_PI_41 = Ts_41 / 2;
Kp_PID_41 = 1.2 * Ks_41;
Ti_PID_41 = 0.5 * Ts_41;
Td_PID_41 = 0.125 * Ts_41;

fprintf('衰减法(4:1)计算得到的PID参数:\n');
fprintf('P控制:   Kp = %.4f\n', Kp_P_41);
fprintf('PI控制:  Kp = %.4f, Ti = %.4f\n', Kp_PI_41, Ti_PI_41);
fprintf('PID控制: Kp = %.4f, Ti = %.4f, Td = %.4f\n\n', Kp_PID_41, Ti_PID_41, Td_PID_41);

%% ==================== 方法二：比例度法 (Ziegler-Nichols临界比例度法) ====================
fprintf('==========================================\n');
fprintf('方法二：比例度法 (Ziegler-Nichols法)\n');
fprintf('==========================================\n\n');

% 比例度法步骤：
% 1. 令Ti=∞, Td=0，逐渐增大Kp
% 2. 直到系统出现等幅振荡（临界稳定）
% 3. 记录临界增益Ku和临界周期Tu
% 4. 按Ziegler-Nichols公式计算PID参数

% 寻找临界增益Ku（系统刚好不稳定时的增益）
Ku = 0;
Tu = 0;

for Kp = linspace(0.01, 10, 1000)
    Gc_p = tf(Kp, 1);
    sys_ol = Gc_p * Gp;
    sys_cl = feedback(sys_ol, 1);
    
    poles = pole(sys_cl);
    % 找到第一个使系统不稳定的Kp
    if any(real(poles) > 0)
        Ku = Kp;
        % 计算临界周期（从虚部）
        imag_parts = abs(imag(poles));
        imag_parts = imag_parts(imag_parts > 0.01);
        if ~isempty(imag_parts)
            omega_u = min(imag_parts);
            Tu = 2 * pi / omega_u;
        end
        break;
    end
end

% 如果没找到，用更大范围
if Ku == 0
    Ku = 2.0;  % 默认值
    Tu = 3.0;
end

fprintf('临界参数:\n');
fprintf('Ku (临界增益) = %.4f\n', Ku);
fprintf('Tu (临界周期) = %.4f s\n\n', Tu);

% Ziegler-Nichols公式
% P控制:   Kp = 0.5*Ku
% PI控制:  Kp = 0.45*Ku, Ti = Tu/1.2
% PID控制: Kp = 0.6*Ku, Ti = Tu/2, Td = Tu/8

Kp_P_ZN = 0.5 * Ku;
Kp_PI_ZN = 0.45 * Ku;
Ti_PI_ZN = Tu / 1.2;
Kp_PID_ZN = 0.6 * Ku;
Ti_PID_ZN = Tu / 2;
Td_PID_ZN = Tu / 8;

fprintf('Ziegler-Nichols法计算得到的PID参数:\n');
fprintf('P控制:   Kp = %.4f\n', Kp_P_ZN);
fprintf('PI控制:  Kp = %.4f, Ti = %.4f\n', Kp_PI_ZN, Ti_PI_ZN);
fprintf('PID控制: Kp = %.4f, Ti = %.4f, Td = %.4f\n\n', Kp_PID_ZN, Ti_PID_ZN, Td_PID_ZN);

%% ==================== 方法三：试凑法 ====================
fprintf('==========================================\n');
fprintf('方法三：试凑法\n');
fprintf('==========================================\n\n');

% 试凑法步骤：
% 1. 先整定比例环节：只用P控制，调节Kp使系统响应较快但有一定超调
% 2. 加入积分环节：减小Kp，加入Ti消除稳态误差
% 3. 加入微分环节：加入Td减小超调，加快响应

% 试凑法 - 通过实验调整得到较好的参数
% 步骤1: 纯P控制调整
fprintf('试凑法调参过程:\n');
fprintf('步骤1: 纯P控制 - 调节Kp使响应较快\n');
Kp_P_trial = 0.8;  % 试凑得到的P参数

% 步骤2: PI控制调整
fprintf('步骤2: PI控制 - 稍减Kp，加入积分消除稳态误差\n');
Kp_PI_trial = 0.6;
Ti_PI_trial = 2.0;

% 步骤3: PID控制调整
fprintf('步骤3: PID控制 - 加入微分减小超调\n');
Kp_PID_trial = 0.9;
Ti_PID_trial = 1.5;
Td_PID_trial = 0.3;

fprintf('\n试凑法得到的PID参数:\n');
fprintf('P控制:   Kp = %.4f\n', Kp_P_trial);
fprintf('PI控制:  Kp = %.4f, Ti = %.4f\n', Kp_PI_trial, Ti_PI_trial);
fprintf('PID控制: Kp = %.4f, Ti = %.4f, Td = %.4f\n\n', Kp_PID_trial, Ti_PID_trial, Td_PID_trial);

%% 构建控制器传递函数
% P控制器: Gc = Kp
% PI控制器: Gc = Kp(1 + 1/(Ti*s)) = Kp*(Ti*s + 1)/(Ti*s)
% PID控制器: Gc = Kp(1 + 1/(Ti*s) + Td*s) (理想PID)
% 实际PID: Gc = Kp*(1 + 1/(Ti*s) + Td*s/(Td/N*s + 1))

% 方法一：衰减法控制器
Gc_P_41 = tf(Kp_P_41, 1);
Gc_PI_41 = tf([Kp_PI_41*Ti_PI_41, Kp_PI_41], [Ti_PI_41, 0]);
Gc_PID_41 = pid(Kp_PID_41, Kp_PID_41/Ti_PID_41, Kp_PID_41*Td_PID_41);

% 方法二：比例度法控制器
Gc_P_ZN = tf(Kp_P_ZN, 1);
Gc_PI_ZN = tf([Kp_PI_ZN*Ti_PI_ZN, Kp_PI_ZN], [Ti_PI_ZN, 0]);
Gc_PID_ZN = pid(Kp_PID_ZN, Kp_PID_ZN/Ti_PID_ZN, Kp_PID_ZN*Td_PID_ZN);

% 方法三：试凑法控制器
Gc_P_trial = tf(Kp_P_trial, 1);
Gc_PI_trial = tf([Kp_PI_trial*Ti_PI_trial, Kp_PI_trial], [Ti_PI_trial, 0]);
Gc_PID_trial = pid(Kp_PID_trial, Kp_PID_trial/Ti_PID_trial, Kp_PID_trial*Td_PID_trial);

%% 绘制三种方法的阶跃响应对比
t = 0:0.01:30;

%% 图1: 衰减法(4:1)的P/PI/PID控制对比
figure('Name', '衰减法', 'Position', [100, 100, 1000, 500]);

sys_P_41 = feedback(Gc_P_41 * Gp, 1);
sys_PI_41 = feedback(Gc_PI_41 * Gp, 1);
sys_PID_41 = feedback(Gc_PID_41 * Gp, 1);

[y_orig, ~] = step(Gc_original, t);
[y_P_41, ~] = step(sys_P_41, t);
[y_PI_41, ~] = step(sys_PI_41, t);
[y_PID_41, ~] = step(sys_PID_41, t);

subplot(1,2,1);
plot(t, y_orig, 'k--', 'LineWidth', 1.5); hold on;
plot(t, y_P_41, 'b', 'LineWidth', 1.5);
plot(t, y_PI_41, 'r', 'LineWidth', 1.5);
plot(t, y_PID_41, 'g', 'LineWidth', 1.5);
xlabel('时间 (s)'); ylabel('输出');
title('衰减法(4:1) - 阶跃响应');
legend('原系统', 'P控制', 'PI控制', 'PID控制', 'Location', 'best');
grid on;

subplot(1,2,2);
stepinfo_P_41 = stepinfo(sys_P_41);
stepinfo_PI_41 = stepinfo(sys_PI_41);
stepinfo_PID_41 = stepinfo(sys_PID_41);

data = [stepinfo_P_41.RiseTime, stepinfo_PI_41.RiseTime, stepinfo_PID_41.RiseTime;
        stepinfo_P_41.SettlingTime, stepinfo_PI_41.SettlingTime, stepinfo_PID_41.SettlingTime;
        stepinfo_P_41.Overshoot, stepinfo_PI_41.Overshoot, stepinfo_PID_41.Overshoot];
bar(data');
set(gca, 'XTickLabel', {'P', 'PI', 'PID'});
legend('上升时间', '调节时间', '超调量%', 'Location', 'best');
title('衰减法 - 性能指标对比');
grid on;

sgtitle('方法一：衰减法 (4:1)');

%% 图2: 比例度法的P/PI/PID控制对比
figure('Name', '比例度法', 'Position', [100, 100, 1000, 500]);

sys_P_ZN = feedback(Gc_P_ZN * Gp, 1);
sys_PI_ZN = feedback(Gc_PI_ZN * Gp, 1);
sys_PID_ZN = feedback(Gc_PID_ZN * Gp, 1);

[y_P_ZN, ~] = step(sys_P_ZN, t);
[y_PI_ZN, ~] = step(sys_PI_ZN, t);
[y_PID_ZN, ~] = step(sys_PID_ZN, t);

subplot(1,2,1);
plot(t, y_orig, 'k--', 'LineWidth', 1.5); hold on;
plot(t, y_P_ZN, 'b', 'LineWidth', 1.5);
plot(t, y_PI_ZN, 'r', 'LineWidth', 1.5);
plot(t, y_PID_ZN, 'g', 'LineWidth', 1.5);
xlabel('时间 (s)'); ylabel('输出');
title('比例度法(Z-N) - 阶跃响应');
legend('原系统', 'P控制', 'PI控制', 'PID控制', 'Location', 'best');
grid on;

subplot(1,2,2);
stepinfo_P_ZN = stepinfo(sys_P_ZN);
stepinfo_PI_ZN = stepinfo(sys_PI_ZN);
stepinfo_PID_ZN = stepinfo(sys_PID_ZN);

data_ZN = [stepinfo_P_ZN.RiseTime, stepinfo_PI_ZN.RiseTime, stepinfo_PID_ZN.RiseTime;
           stepinfo_P_ZN.SettlingTime, stepinfo_PI_ZN.SettlingTime, stepinfo_PID_ZN.SettlingTime;
           stepinfo_P_ZN.Overshoot, stepinfo_PI_ZN.Overshoot, stepinfo_PID_ZN.Overshoot];
bar(data_ZN');
set(gca, 'XTickLabel', {'P', 'PI', 'PID'});
legend('上升时间', '调节时间', '超调量%', 'Location', 'best');
title('比例度法 - 性能指标对比');
grid on;

sgtitle('方法二：比例度法 (Ziegler-Nichols)');

%% 图3: 试凑法的P/PI/PID控制对比
figure('Name', '试凑法', 'Position', [100, 100, 1000, 500]);

sys_P_trial = feedback(Gc_P_trial * Gp, 1);
sys_PI_trial = feedback(Gc_PI_trial * Gp, 1);
sys_PID_trial = feedback(Gc_PID_trial * Gp, 1);

[y_P_trial, ~] = step(sys_P_trial, t);
[y_PI_trial, ~] = step(sys_PI_trial, t);
[y_PID_trial, ~] = step(sys_PID_trial, t);

subplot(1,2,1);
plot(t, y_orig, 'k--', 'LineWidth', 1.5); hold on;
plot(t, y_P_trial, 'b', 'LineWidth', 1.5);
plot(t, y_PI_trial, 'r', 'LineWidth', 1.5);
plot(t, y_PID_trial, 'g', 'LineWidth', 1.5);
xlabel('时间 (s)'); ylabel('输出');
title('试凑法 - 阶跃响应');
legend('原系统', 'P控制', 'PI控制', 'PID控制', 'Location', 'best');
grid on;

subplot(1,2,2);
stepinfo_P_trial = stepinfo(sys_P_trial);
stepinfo_PI_trial = stepinfo(sys_PI_trial);
stepinfo_PID_trial = stepinfo(sys_PID_trial);

data_trial = [stepinfo_P_trial.RiseTime, stepinfo_PI_trial.RiseTime, stepinfo_PID_trial.RiseTime;
              stepinfo_P_trial.SettlingTime, stepinfo_PI_trial.SettlingTime, stepinfo_PID_trial.SettlingTime;
              stepinfo_P_trial.Overshoot, stepinfo_PI_trial.Overshoot, stepinfo_PID_trial.Overshoot];
bar(data_trial');
set(gca, 'XTickLabel', {'P', 'PI', 'PID'});
legend('上升时间', '调节时间', '超调量%', 'Location', 'best');
title('试凑法 - 性能指标对比');
grid on;

sgtitle('方法三：试凑法');

%% 图4: 三种方法的PID控制效果总对比
figure('Name', '三种方法PID对比', 'Position', [100, 100, 1200, 500]);

subplot(1,2,1);
plot(t, y_orig, 'k--', 'LineWidth', 2); hold on;
plot(t, y_PID_41, 'b', 'LineWidth', 1.5);
plot(t, y_PID_ZN, 'r', 'LineWidth', 1.5);
plot(t, y_PID_trial, 'g', 'LineWidth', 1.5);
xlabel('时间 (s)'); ylabel('输出');
title('三种方法PID控制阶跃响应对比');
legend('原系统', '衰减法PID', '比例度法PID', '试凑法PID', 'Location', 'best');
grid on;

subplot(1,2,2);
methods = {'衰减法', '比例度法', '试凑法'};
rise_times = [stepinfo_PID_41.RiseTime, stepinfo_PID_ZN.RiseTime, stepinfo_PID_trial.RiseTime];
settling_times = [stepinfo_PID_41.SettlingTime, stepinfo_PID_ZN.SettlingTime, stepinfo_PID_trial.SettlingTime];
overshoots = [stepinfo_PID_41.Overshoot, stepinfo_PID_ZN.Overshoot, stepinfo_PID_trial.Overshoot];

bar_data = [rise_times; settling_times; overshoots]';
bar(bar_data);
set(gca, 'XTickLabel', methods);
legend('上升时间(s)', '调节时间(s)', '超调量(%)', 'Location', 'best');
title('三种方法PID性能指标对比');
grid on;

sgtitle('三种PID整定方法对比');

%% 打印三种方法特点对比
fprintf('\n==========================================\n');
fprintf('        三种方法特点对比总结\n');
fprintf('==========================================\n\n');

fprintf('【方法一：衰减曲线法 (4:1)】\n');
fprintf('优点：\n');
fprintf('  - 基于系统实际响应特性，参数可靠\n');
fprintf('  - 获得的系统响应相对平稳，超调较小\n');
fprintf('  - 适用于要求响应平稳的场合\n');
fprintf('缺点：\n');
fprintf('  - 需要反复调整Kp以获得4:1衰减比\n');
fprintf('  - 对操作人员经验要求较高\n');
fprintf('  - 响应速度相对较慢\n\n');

fprintf('【方法二：比例度法 (Ziegler-Nichols)】\n');
fprintf('优点：\n');
fprintf('  - 方法简单，只需测量临界增益和临界周期\n');
fprintf('  - 有明确的计算公式，易于实现\n');
fprintf('  - 响应速度较快\n');
fprintf('缺点：\n');
fprintf('  - 可能产生较大超调（约25%%）\n');
fprintf('  - 需要使系统达到临界振荡状态，有一定风险\n');
fprintf('  - 对某些系统可能不适用\n\n');

fprintf('【方法三：试凑法】\n');
fprintf('优点：\n');
fprintf('  - 灵活性高，可根据实际需求调整\n');
fprintf('  - 能够获得满足特定要求的最佳参数\n');
fprintf('  - 适用于各种类型的系统\n');
fprintf('缺点：\n');
fprintf('  - 耗时较长，需要多次试验\n');
fprintf('  - 对操作人员经验要求很高\n');
fprintf('  - 结果依赖于个人经验，可重复性差\n\n');

fprintf('==========================================\n');
fprintf('        PID参数汇总表\n');
fprintf('==========================================\n');
fprintf('%-12s | %-8s | %-8s | %-8s\n', '方法', 'Kp', 'Ti', 'Td');
fprintf('--------------------------------------------\n');
fprintf('%-12s | %-8.4f | %-8s | %-8s\n', '衰减法-P', Kp_P_41, '-', '-');
fprintf('%-12s | %-8.4f | %-8.4f | %-8s\n', '衰减法-PI', Kp_PI_41, Ti_PI_41, '-');
fprintf('%-12s | %-8.4f | %-8.4f | %-8.4f\n', '衰减法-PID', Kp_PID_41, Ti_PID_41, Td_PID_41);
fprintf('--------------------------------------------\n');
fprintf('%-12s | %-8.4f | %-8s | %-8s\n', '比例度法-P', Kp_P_ZN, '-', '-');
fprintf('%-12s | %-8.4f | %-8.4f | %-8s\n', '比例度法-PI', Kp_PI_ZN, Ti_PI_ZN, '-');
fprintf('%-12s | %-8.4f | %-8.4f | %-8.4f\n', '比例度法-PID', Kp_PID_ZN, Ti_PID_ZN, Td_PID_ZN);
fprintf('--------------------------------------------\n');
fprintf('%-12s | %-8.4f | %-8s | %-8s\n', '试凑法-P', Kp_P_trial, '-', '-');
fprintf('%-12s | %-8.4f | %-8.4f | %-8s\n', '试凑法-PI', Kp_PI_trial, Ti_PI_trial, '-');
fprintf('%-12s | %-8.4f | %-8.4f | %-8.4f\n', '试凑法-PID', Kp_PID_trial, Ti_PID_trial, Td_PID_trial);
fprintf('==========================================\n\n');

%% 性能指标汇总
fprintf('==========================================\n');
fprintf('        PID控制性能指标汇总\n');
fprintf('==========================================\n');
fprintf('%-12s | %-10s | %-10s | %-10s\n', '方法', '上升时间', '调节时间', '超调量(%)');
fprintf('----------------------------------------------------\n');
fprintf('%-12s | %-10.4f | %-10.4f | %-10.2f\n', '衰减法-PID', ...
    stepinfo_PID_41.RiseTime, stepinfo_PID_41.SettlingTime, stepinfo_PID_41.Overshoot);
fprintf('%-12s | %-10.4f | %-10.4f | %-10.2f\n', '比例度法-PID', ...
    stepinfo_PID_ZN.RiseTime, stepinfo_PID_ZN.SettlingTime, stepinfo_PID_ZN.Overshoot);
fprintf('%-12s | %-10.4f | %-10.4f | %-10.2f\n', '试凑法-PID', ...
    stepinfo_PID_trial.RiseTime, stepinfo_PID_trial.SettlingTime, stepinfo_PID_trial.Overshoot);
fprintf('==========================================\n');
